#include <stdlib.h>
#include <connectionHandler.h>

#include <thread>
#include <functional>
#include <mutex>
#include <condition_variable>

using namespace std;

void client_input(ConnectionHandler &, mutex &, condition_variable &, bool &);

int main(int argc, char **argv) {
    if(argc < 3) {
        cerr << "Usage: " << argv[0] << " host port" << endl;
        return -1;
    }
    std::string host = argv[1];
    short port = atoi(argv[2]);
    ConnectionHandler conn(host, port);
    mutex m;
    condition_variable cv;
    bool connected = conn.connect();
    if(!connected) {
        cerr << "Cannot connect to " << host << ":" << port << endl;
        return 1;
    }
    thread input_thread{client_input, ref(conn), ref(m), ref(cv), ref(connected)};
    while(connected) {
        std::string answer;
        if(!conn.getLine(answer)) {
            std::cout << "get line failed" << endl;
            break;
        }
        cout << answer << endl;
        if(answer == "ERROR 4" || answer == "ACK 4") {
		{
          		lock_guard<mutex> lk(m);
			connected = (answer == "ERROR 4");
		}
		cv.notify_one();
		if (!connected)
			input_thread.join();
        }
    }
    return 0;
}

void client_input(ConnectionHandler &conn, mutex &m, condition_variable &cv, bool &connected) {
    char buf[1024];
    while(connected) {
        cin.getline(buf, sizeof(buf));
        string line(buf);
        if(!conn.sendLine(line)) {
            cout << "send line failed" << endl;
            break;
        }
        if(line == "LOGOUT") {
            unique_lock<mutex> lk(m);
            cv.wait(lk);
        }
    }
}
