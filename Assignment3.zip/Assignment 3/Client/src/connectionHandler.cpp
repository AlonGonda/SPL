#include <connectionHandler.h>

using boost::asio::ip::tcp;
using namespace std;

ConnectionHandler::ConnectionHandler(string host, short port): host_(host), port_(port), io_service_(), socket_(io_service_), opcodes {"ADMINREG", "STUDENTREG", "LOGIN", "LOGOUT", "COURSEREG", "KDAMCHECK", "COURSESTAT", "STUDENTSTAT", "ISREGISTERED", "UNREGISTER", "MYCOURSES", "ACK", "ERROR"}
{}

ConnectionHandler::~ConnectionHandler() {
    close();
}

bool ConnectionHandler::connect() {
    cout << "Starting connect to "
         << host_ << ":" << port_ << endl;
    try {
        tcp::endpoint endpoint(boost::asio::ip::address::from_string(host_), port_); // the server endpoint
        boost::system::error_code error;
        socket_.connect(endpoint, error);
        if(error)
            throw boost::system::system_error(error);
    }
    catch(exception& e) {
        cerr << "Connection failed (Error: " << e.what() << ')' << endl;
        return false;
    }
    return true;
}

bool ConnectionHandler::getBytes(char bytes[], unsigned int bytesToRead) {
    size_t tmp = 0;
    boost::system::error_code error;
    try {
        while(!error && bytesToRead > tmp) {
            tmp += socket_.read_some(boost::asio::buffer(bytes + tmp, bytesToRead - tmp), error);
        }
        if(error)
            throw boost::system::system_error(error);
    } catch(exception& e) {
        cerr << "recv failed (Error: " << e.what() << ')' << endl;
        return false;
    }
    return true;
}

bool ConnectionHandler::sendBytes(const char bytes[], int bytesToWrite) {
    int tmp = 0;
    boost::system::error_code error;
    try {
        while(!error && bytesToWrite > tmp) {
            tmp += socket_.write_some(boost::asio::buffer(bytes + tmp, bytesToWrite - tmp), error);
        }
        if(error)
            throw boost::system::system_error(error);
    } catch(exception& e) {
        cerr << "recv failed (Error: " << e.what() << ')' << endl;
        return false;
    }
    return true;
}

bool ConnectionHandler::send_message(short opcode, const string *s1, const string *s2, short course) {
    if(course >= 0) {
        char msg[4];
        stob(opcode, msg);
        stob(course, msg + 2);
        return sendBytes(msg, sizeof(msg));
    }
    int size = 2;
    if(s1)
        size += s1->length() + 1;
    if(s2)
        size += s2->length() + 1;
    char *message = new char[size];
    stob(opcode, message);
    message += 2;
    if(s1) {
        const char *ps = s1->c_str();
        while(*ps) {
            *message++ = *ps++;
        }
        *message++ = 0;
    }
    if(s2) {
        const char *ps = s2->c_str();
        while(*ps) {
            *message++ = *ps++;
        }
        *message++ = 0;
    }
    message -= size;
    bool success = sendBytes(message, size);
    delete[] message;
    return success;
}

bool ConnectionHandler::getLine(string& line) {
    return getFrameAscii(line, '\0');
}

bool ConnectionHandler::sendLine(string& line) {
    return sendFrameAscii(line, '\0');
}


bool ConnectionHandler::getFrameAscii(string& frame, char delimiter) {
    // Stop when we encounter the null character.
    // Notice that the null character is not appended to the frame string.
    char op[2];
    if(!getBytes(op, 2))
        return false;
    short answer_op_code = btos(op);
    frame.append(opcodes[answer_op_code - 1]);
    frame.append(" ");
    if(!getBytes(op, 2))
        return false;
    short sent_op_code = btos(op);
    frame.append(to_string(sent_op_code));
    if(answer_op_code == ERR)
        return true;
    if(has_optional(sent_op_code))
        try {
            frame.append("\n");
            char ch;
            do {
                if(!getBytes(&ch, 1))
                    return false;
                if(ch != delimiter)
                    frame.append(1, ch);
            } while(delimiter != ch);
        } catch(exception& e) {
            cerr << "recv failed2 (Error: " << e.what() << ')' << endl;
            return false;
        }
    return true;
}


bool ConnectionHandler::sendFrameAscii(const std::string& frame, char delimiter) {
    // find op code
    int pos = frame.find(" ");
    short opcode = get_opcode(frame.substr(0, pos));
    string to_send = frame.substr(pos + 1);
    if(!opcode)
        return false;
//    char op[2];
//    stob(opcode, op);
//    if(!sendBytes(op, 2))
//        return false;
    switch(opcode) {
    case ADMINREG:
    case STUDENTREG:
    case LOGIN:
    {
        pos = to_send.find(" ");
        // send null terminating char as well
        string s1 = to_send.substr(0, pos);
//        if(!sendBytes(to_send.substr(0, pos).c_str(), pos + 1))
//            return false;
        string s2 = to_send.substr(pos + 1);
        // to_send = to_send.substr(pos + 1);
        //return sendBytes(to_send.c_str(), to_send.length() + 1);
        return send_message(opcode, &s1, &s2, -1);
    }
    case LOGOUT:
    case MYCOURSES:
        return send_message(opcode, nullptr, nullptr, -1);
    case COURSEREG:
    case KDAMCHECK:
    case COURSESTAT:
    case ISREGISTERED:
    case UNREGISTER:
//        char op[2];
//        stob(static_cast<short>(stoi(to_send)), op);
//        return sendBytes(op, 2);
        return send_message(opcode, nullptr, nullptr, static_cast<short>(stoi(to_send)));
    case STUDENTSTAT:
        //return sendBytes(frame.c_str(), frame.length() + 1);
        return send_message(opcode, &to_send, nullptr, -1);
    default:
        return false;
    }
}

// Close down the connection properly.
void ConnectionHandler::close() {
    try {
        socket_.close();
    } catch(...) {
        cout << "closing failed: connection already closed" << endl;
    }
}

short ConnectionHandler::get_opcode(string&& s) {
    for(short i = 0; i < 13; i++) {
        if(opcodes[i] == s)
            return i + 1;
    }
    return 0;
}

void stob(short num, char *bytes) {
    *bytes++ = ((num >> 8) & 0xFF);
    *bytes = (num & 0xFF);
}

short btos(char *bytes) {
    return static_cast<short>(((bytes[0] & 0xff) << 8) | (bytes[1] & 0xff));
}

bool has_optional(short op_code) {
    return (6 <= op_code) && (op_code <= 11) && (op_code != 10);
}



