package bgu.spl.net.impl.BGRSServer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * This class saves the data for each course from the DataBase
 */
public class Course implements Comparable<Course> {

	private final static char SEPERATOR = '|';

	private Short courseNum;
	private String courseName;
	private ArrayList<Short> kdamCourses;
	private int maxNumOfStudents;
	private ConcurrentLinkedQueue<User> regStudents;
	private int insertionTime;

	public Course(String rawCourse, int insert) {
		int pos = rawCourse.indexOf(SEPERATOR);
		courseNum = Short.parseShort(rawCourse.substring(0, pos++));
		rawCourse = rawCourse.substring(pos);
		pos = rawCourse.indexOf(SEPERATOR);
		courseName = rawCourse.substring(0, pos++);
		rawCourse = rawCourse.substring(pos);
		pos = rawCourse.indexOf(SEPERATOR);
		parseKdamCourses(rawCourse.substring(0, pos++));
		maxNumOfStudents = Integer.parseInt(rawCourse.substring(pos));
		regStudents = new ConcurrentLinkedQueue<>();
		insertionTime = insert;
	}

	private void parseKdamCourses(String rawKdams) {
		kdamCourses = new ArrayList<>();
		rawKdams = rawKdams.substring(1, rawKdams.length() - 1);
		int pos;
		while ((pos = rawKdams.indexOf(',')) >= 0) {
			kdamCourses.add(Short.parseShort(rawKdams.substring(0, pos++)));
			rawKdams = rawKdams.substring(pos);
		}
		if (rawKdams.length() > 0)
			kdamCourses.add(Short.parseShort(rawKdams));
	}

	public short getCourseNum() {
		return courseNum;
	}

	public String getCourseName() {
		return courseName;
	}

	public ArrayList<Short> getKdamCourseList() {
		return kdamCourses;
	}

	public void setKdamCourseList(ArrayList<Short> updated) {
		kdamCourses = updated;
	}

	public int getMaxNumOfStudents() {
		return maxNumOfStudents;
	}

	public void regStudent(User toReg) {
		regStudents.add(toReg);
	}

	public void unregStudent(User toUnReg) {
		regStudents.remove(toUnReg);
	}

	public int getAvailableSeats() {
		return maxNumOfStudents - regStudents.size();
	}

	public ConcurrentLinkedQueue<User> getRegStudents() {
		return regStudents;
	}

	@Override
	public int compareTo(Course o) {
		return Integer.compare(insertionTime, o.insertionTime);
	}

	private String sortedRegisteredStudents() {
		User[] u = new User[regStudents.size()];
		regStudents.toArray(u);
		String[] names = new String[u.length];
		for (int i = 0; i < names.length; i++) {
			names[i] = u[i].getUsername();
		}
		Arrays.sort(names, (s1, s2) -> s1.compareTo(s2));
		String s = Arrays.toString(names);
		String o = "";
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (c != ' ')
				o += c;
		}
		return o;
	}

	@Override
	public String toString() {
		return String.format("Course: (%d) %s\nSeats Available: %d/%d\nStudents Registered: %s", courseNum, courseName,
				getAvailableSeats(), maxNumOfStudents, sortedRegisteredStudents());
	}

}
