package bgu.spl.net.impl.BGRSServer;

import bgu.spl.net.srv.Server;

public class TPCMain {

	public static void main(String[] args) {
		if (Database.getInstance().initialize("Courses.txt") && args.length == 1)
			Server.threadPerClient(Integer.parseInt(args[0]), () -> new BgrsProtocol(), () -> new BgrsEncoderDecoder()).serve();
		else
			System.out.println("couldn't init database or server");
	}

}
