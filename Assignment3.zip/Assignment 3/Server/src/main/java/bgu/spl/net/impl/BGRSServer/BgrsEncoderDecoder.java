package bgu.spl.net.impl.BGRSServer;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;

import bgu.spl.net.api.MessageEncoderDecoder;

public class BgrsEncoderDecoder implements MessageEncoderDecoder<Message> {

	private byte[] bytes;
	private int len;
	private int counter;
	private boolean waitingForType;
	private Message msg;

	public BgrsEncoderDecoder() {
		bytes = new byte[1 << 10];
		len = 0;
		counter = 0;
		waitingForType = true;
		msg = new Message();
	}

	@Override
	public Message decodeNextByte(byte nextByte) {
		pushByte(nextByte);
		if (len == 2 && waitingForType) {
			msg.setType(popShort());
			waitingForType = false;
		}
		if (!waitingForType)
			switch (msg.getType()) {
				case ADMINREG:
				case STUDENTREG:
				case LOGIN:
					if (nextByte != 0)
						break;
					counter++;
					switch (counter) {
						case 1:
							msg.setUsername(popString());
							break;
						case 2:
							counter = 0;
							msg.setPassword(popString());
							return popMessage();
					}
					break;
				case STUDENTSTAT:
					if (nextByte != 0)
						break;
					msg.setUsername(popString());
					return popMessage();
				case COURSEREG:
				case KDAMCHECK:
				case COURSESTAT:
				case ISREGISTERED:
				case UNREGISTER:
					if (len < 2)
						break;
					msg.setCourseNumber(popShort());
					return popMessage();
				case LOGOUT:
				case MYCOURSES:
					return popMessage();
				default:
					break;
			}
		return null;
	}

	@Override
	public byte[] encode(Message message) {
		byte[] encoded = shortToBytes(message.getType().valueOf());
		for (int i = 0; i < encoded.length; i++) {
			pushByte(encoded[i]);
		}
		encoded = shortToBytes(message.getClientType().valueOf());
		for (int i = 0; i < encoded.length; i++) {
			pushByte(encoded[i]);
		}
		if (message.hasData()) {
			encoded = message.getData().getBytes();
			for (int i = 0; i < encoded.length; i++) {
				pushByte(encoded[i]);
			}
			pushByte((byte) 0);
		}
		return popBytes();
	}

	private void pushByte(byte nextByte) {
		if (len >= bytes.length) {
			bytes = Arrays.copyOf(bytes, len * 2);
		}

		bytes[len++] = nextByte;
	}

	private byte[] popBytes() {
		byte[] b = Arrays.copyOfRange(bytes, 0, len);
		len = 0;
		return b;
	}

	private String popString() {
		// notice that we explicitly requesting that the string will be decoded
		// from UTF-8
		// this is not actually required as it is the default encoding in java.
		String result = new String(bytes, 0, len - 1, StandardCharsets.UTF_8);
		len = 0;
		return result;
	}

	private short popShort() {
		len = 0;
		return bytesToShort(bytes[0], bytes[1]);
	}

	private Message popMessage() {
		waitingForType = true;
		return msg;
	}

	private short bytesToShort(byte high, byte low) {
		return (short) (((high & 0xff) << 8) | (low & 0xff));
	}

	private byte[] shortToBytes(short num) {
		byte[] bytesArr = new byte[2];
		bytesArr[0] = (byte) ((num >> 8) & 0xFF);
		bytesArr[1] = (byte) (num & 0xFF);
		return bytesArr;
	}
}
