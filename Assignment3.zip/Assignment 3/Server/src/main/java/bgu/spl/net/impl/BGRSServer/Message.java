package bgu.spl.net.impl.BGRSServer;

public class Message {

	private MessageType type;
	private String username;
	private String password;
	private short courseNumber;
	private MessageType clientType;
	private String data;

	public void setType(Short typeNum) {
		switch (typeNum) {
			case 1:
				type = MessageType.ADMINREG;
				break;
			case 2:
				type = MessageType.STUDENTREG;
				break;
			case 3:
				type = MessageType.LOGIN;
				break;
			case 4:
				type = MessageType.LOGOUT;
				break;
			case 5:
				type = MessageType.COURSEREG;
				break;
			case 6:
				type = MessageType.KDAMCHECK;
				break;
			case 7:
				type = MessageType.COURSESTAT;
				break;
			case 8:
				type = MessageType.STUDENTSTAT;
				break;
			case 9:
				type = MessageType.ISREGISTERED;
				break;
			case 10:
				type = MessageType.UNREGISTER;
				break;
			case 11:
				type = MessageType.MYCOURSES;
				break;
			case 12:
				type = MessageType.ACK;
				break;
			case 13:
				type = MessageType.ERR;
				break;
		}
	}

	public void setType(MessageType type) {
		this.type = type;
	}

	public void setClientType(MessageType clientType) {
		this.clientType = clientType;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setCourseNumber(short courseNumber) {
		this.courseNumber = courseNumber;
	}

	public void setData(String data) {
		this.data = data;
	}

	public MessageType getType() {
		return type;
	}

	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}

	public short getCourseNumber() {
		return courseNumber;
	}

	public MessageType getClientType() {
		return clientType;
	}

	public boolean hasData() {
		return (data != null);
	}

	public String getData() {
		return data;
	}

}
