package bgu.spl.net.impl.BGRSServer;

import bgu.spl.net.srv.Server;

public class ReactorMain {

	public static void main(String[] args) {
		if (Database.getInstance().initialize("Courses.txt") && args.length == 2)
			Server.reactor(Integer.parseInt(args[1]), Integer.parseInt(args[0]), // port
					() -> new BgrsProtocol(), // protocol factory
					() -> new BgrsEncoderDecoder() // message encoder decoder
													// factory
			).serve();
		else
			System.out.println("couldn't init database or server");
	}

}
