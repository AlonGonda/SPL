package bgu.spl.net.impl.BGRSServer;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Passive object representing the Database where all courses and users are
 * stored.
 * <p>
 * This class must be implemented safely as a thread-safe singleton. You must
 * not alter any of the given public methods of this class.
 * <p>
 * You can add private fields and methods to this class as you see fit.
 */

public class Database {

	private ConcurrentHashMap<String, User> usersAndPasswords;
	private ConcurrentHashMap<Short, Course> courseInfo;
	private ConcurrentLinkedQueue<String> loggedIn;

	private static final Database instance = new Database();

	// to prevent user from creating new Database
	private Database() {
		// TODO: implement
		usersAndPasswords = new ConcurrentHashMap<>();
		courseInfo = new ConcurrentHashMap<>();
		loggedIn = new ConcurrentLinkedQueue<>();
	}

	public ArrayList<Short> getUserCoursesList(String username) {
		if (username != null && !isAdmin(username)) {
			return usersAndPasswords.get(username).getCourses();
		}
		return null;
	}

	public boolean unregisterUserFromCourse(String username, short course) {
		if (username != null && existCourse(course)) {
			User current = usersAndPasswords.get(username);
			Course currentCourse = courseInfo.get(course);
			synchronized (currentCourse) {
				if (current.unregister(course)) {
					currentCourse.unregStudent(current);
					return true;
				}
			}
		}
		return false;
	}

	public User getUserData(String posAdmin, String username) {
		if (posAdmin != null && usersAndPasswords.get(posAdmin).isAdmin() && username != null) {
			return usersAndPasswords.get(username);
		}
		return null;
	}

	public Course getCourseStat(String username, short course) {
		if (username != null && existCourse(course) && usersAndPasswords.get(username).isAdmin()) {
			Course current = courseInfo.get(course);
			return current;
		}
		return null;
	}

	private boolean existCourse(short course) {
		return courseInfo.containsKey(course);
	}

	public ArrayList<Short> getKdamCourses(String username, short course) {
		if (username != null && !isAdmin(username) && existCourse(course)) {
			return courseInfo.get(course).getKdamCourseList();
		}
		return null;
	}

	public boolean logout(String username) {
		if (!isLoggedIn(username))
			return false;
		loggedIn.remove(username);
		return true;
	}

	private boolean isLoggedIn(String username) {
		for (String user : loggedIn) {
			if (user.equals(username))
				return true;
		}
		return false;
	}

	public synchronized String login(String username, String password) {
		if (userExist(username) && usersAndPasswords.get(username).isPassword(password) && !isLoggedIn(username)) {
			loggedIn.add(username);
			return username;
		}
		return null;
	}

	public int isRegisteredToCourse(String username, short courseNum) {
		if (username != null && !isAdmin(username) && courseInfo.containsKey(courseNum))
			return usersAndPasswords.get(username).isRegistered(courseNum) ? 1 : -1;
		return 0;
	}

	private boolean userExist(String username) {
		return usersAndPasswords.containsKey(username);
	}

	public synchronized boolean addUser(String username, String password, boolean isAdmin) {
		if (!userExist(username)) {
			usersAndPasswords.put(username, new User(username, password, isAdmin));
			return true;
		}
		return false;
	}

	public boolean registerToCourse(String username, short courseNum) {
		if (username != null && !isAdmin(username) && existCourse(courseNum)) {
			Course currentCourse = courseInfo.get(courseNum);
			synchronized (currentCourse) {
				if (currentCourse.getMaxNumOfStudents() > currentCourse.getRegStudents().size()) {
					User currentUser = usersAndPasswords.get(username);
					boolean registered = currentUser.insertNewCourse(courseNum, currentCourse.getKdamCourseList());
					if (registered) {
						currentCourse.regStudent(currentUser);
						currentUser.getCourses().sort((a, b) -> courseInfo.get(a).compareTo(courseInfo.get(b)));
						return true;
					}
				}
			}
		}
		return false;
	}

	private boolean isAdmin(String username) {
		return usersAndPasswords.containsKey(username) && usersAndPasswords.get(username).isAdmin();
	}

	/**
	 * Retrieves the single instance of this class.
	 */
	public static Database getInstance() {
		return instance;
	}

	/**
	 * loades the courses from the file path specified into the Database,
	 * returns true if successful.
	 */
	boolean initialize(String coursesFilePath) {
		BufferedReader in = null;
		try {
			FileReader fin = new FileReader(new File(coursesFilePath));
			in = new BufferedReader(fin);
			String line;
			int insert = 0;
			while ((line = in.readLine()) != null) {
				Course c = new Course(line, insert++);
				courseInfo.put(c.getCourseNum(), c);
			}
			sortKdams();
			return true;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (in != null)
				try {
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
		return false;
	}

	private void sortKdams() {
		for (Course course : courseInfo.values())
			course.getKdamCourseList().sort((a, b) -> courseInfo.get(a).compareTo(courseInfo.get(b)));
	}

}