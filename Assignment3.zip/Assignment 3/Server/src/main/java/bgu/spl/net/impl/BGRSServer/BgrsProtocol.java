package bgu.spl.net.impl.BGRSServer;

import java.util.ArrayList;

import bgu.spl.net.api.MessagingProtocol;

public class BgrsProtocol implements MessagingProtocol<Message> {

	private Message ans;
	private Message msg;
	private String currentUser;
	private Database db;
	private boolean termination;

	public BgrsProtocol() {
		ans = new Message();
		// explicitly initialize to null
		currentUser = null;
		db = Database.getInstance();
		termination = false;
	}

	@Override
	public Message process(Message msg) {
		this.msg = msg;
		switch (msg.getType()) {
			case ADMINREG:
				adminReg();
				break;
			case COURSEREG:
				courseReg();
				break;
			case COURSESTAT:
				courseStat();
				break;
			case ISREGISTERED:
				isRegistered();
				break;
			case KDAMCHECK:
				kdamCheck();
				break;
			case LOGIN:
				login();
				break;
			case LOGOUT:
				logout();
				break;
			case MYCOURSES:
				myCourses();
				break;
			case STUDENTREG:
				studentReg();
				break;
			case STUDENTSTAT:
				studentStat();
				break;
			case UNREGISTER:
				unregister();
				break;
			default:
				ans = null;
				break;
		}
		return ans;
	}

	@Override
	public boolean shouldTerminate() {
		return termination;
	}

	private void adminReg() {
		boolean isRegistered = (currentUser == null) && db.addUser(msg.getUsername(), msg.getPassword(), true);
		composeAnswer(isRegistered, null);
	}

	private void courseReg() {
		boolean isRegistered = db.registerToCourse(currentUser, msg.getCourseNumber());
		composeAnswer(isRegistered, null);
	}

	private void courseStat() {
		Course c = db.getCourseStat(currentUser, msg.getCourseNumber());
		if (c != null)
			composeAnswer(true, c.toString());
		else
			composeAnswer(false, null);
	}

	private void isRegistered() {
		int isRegistered = db.isRegisteredToCourse(currentUser, msg.getCourseNumber());
		composeAnswer(isRegistered != 0,
				(isRegistered == 0) ? null : (isRegistered == 1) ? "REGISTERED" : "NOT REGISTERED");

	}

	private void kdamCheck() {
		ArrayList<Short> kdams = db.getKdamCourses(currentUser, msg.getCourseNumber());
		if (kdams == null)
			composeAnswer(false, null);
		else
			composeAnswer(true, noSpaces(kdams));
	}

	private void login() {
		currentUser = db.login(msg.getUsername(), msg.getPassword());
		composeAnswer((currentUser != null), null);
	}

	private void logout() {
		boolean success = db.logout(currentUser);
		composeAnswer(success, null);
		if (success) {
			currentUser = null;
			termination = true;
		}
	}

	private void myCourses() {
		ArrayList<Short> myCourses = db.getUserCoursesList(currentUser);
		if (myCourses == null) {
			composeAnswer(false, null);
			return;
		}
		composeAnswer(true, noSpaces(myCourses));
	}

	private void studentReg() {
		boolean isRegistered = (currentUser == null) && db.addUser(msg.getUsername(), msg.getPassword(), false);
		composeAnswer(isRegistered, null);
	}

	private void studentStat() {
		User data = db.getUserData(currentUser, msg.getUsername());
		if (data != null)
			composeAnswer(true, data.toString());
		else
			composeAnswer(false, null);
	}

	private void unregister() {
		boolean isDone = db.unregisterUserFromCourse(currentUser, msg.getCourseNumber());
		composeAnswer(isDone, null);
	}

	private void composeAnswer(boolean success, String optional) {
		ans.setType((success) ? MessageType.ACK : MessageType.ERR);
		ans.setClientType(msg.getType());
		ans.setData(optional);
	}

	private <T> String noSpaces(ArrayList<T> a) {
		String s = a.toString();
		String o = "";
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (c != ' ')
				o += c;
		}
		return o;
	}

}
