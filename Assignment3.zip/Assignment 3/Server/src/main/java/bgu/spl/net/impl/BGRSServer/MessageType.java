package bgu.spl.net.impl.BGRSServer;

public enum MessageType {

	ADMINREG, STUDENTREG, LOGIN, LOGOUT, COURSEREG, KDAMCHECK, COURSESTAT, STUDENTSTAT, ISREGISTERED, UNREGISTER, MYCOURSES, ACK, ERR;

	public Short valueOf() {
		switch (this) {
			case ACK:
				return 12;
			case ADMINREG:
				return 1;
			case COURSEREG:
				return 5;
			case COURSESTAT:
				return 7;
			case ISREGISTERED:
				return 9;
			case KDAMCHECK:
				return 6;
			case LOGIN:
				return 3;
			case LOGOUT:
				return 4;
			case MYCOURSES:
				return 11;
			case STUDENTREG:
				return 2;
			case STUDENTSTAT:
				return 8;
			case UNREGISTER:
				return 10;
			case ERR:
			default:
				return 13;
		}
	}

}
