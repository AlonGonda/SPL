package bgu.spl.net.impl.BGRSServer;

import java.util.ArrayList;

public class User {

	private String username;
	private String password;
	private boolean isAdmin;
	private ArrayList<Short> courses;

	public User(String userName, String psword, boolean isAd) {
		username = userName;
		password = psword;
		isAdmin = isAd;
		courses = new ArrayList<>();
	}

	public ArrayList<Short> getCourses() {
		return courses;
	}

	public boolean isPassword(String other) {
		return password.equals(other);
	}

	public boolean hasAllKdam(Short course, ArrayList<Short> kdamCourse) {
		for (Short kdam : kdamCourse) {
			if (!isRegistered(kdam))
				return false;
		}
		return true;
	}

	public boolean insertNewCourse(Short course, ArrayList<Short> kdamCourse) {
		if (!isRegistered(course) && hasAllKdam(course, kdamCourse)) {
			courses.add(course);
			return true;
		}
		return false;
	}

	public boolean unregister(Short course) {
		if (isRegistered(course)) {
			courses.remove(course);
			return true;
		}
		return false;
	}

	public boolean isRegistered(Short course) {
		return courses.contains(course);
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isAdmin() {
		return isAdmin;
	}

	public void setAdmin(boolean admin) {
		isAdmin = admin;
	}

	@Override
	public String toString() {
		//courses.sort((s1, s2) -> s1.compareTo(s2));
		String s = courses.toString();
		String o = "";
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (c != ' ')
				o += c;
		}
		return String.format("Student: %s\nCourses: %s", username, o);
	}

}
