package bgu.spl.mics.application.passiveObjects;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EwokTest {

    Ewok test;
    @BeforeEach
    void setUp() {
        test = new Ewok(1);
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void acquire() {
        test.acquire();
        assertFalse(test.isAvailable());
    }

    @Test
    void release() {
        test.release();
        assertTrue(test.isAvailable());
    }
}
