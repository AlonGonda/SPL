package bgu.spl.mics;

import bgu.spl.mics.example.messages.ExampleBroadcast;
import bgu.spl.mics.example.messages.ExampleEvent;
import bgu.spl.mics.example.services.ExampleBroadcastListenerService;
import bgu.spl.mics.example.services.ExampleEventHandlerService;
import bgu.spl.mics.example.services.ExampleMessageSenderService;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class MessageBusImplTest {
    private  MessageBus test;
    @BeforeEach
    void setUp() {
        test = MessageBusImpl.getInstance();
    }



    @AfterEach
    void tearDown() {
    }

    @Test
    void complete() {
System.out.println("complete");
        ExampleEventHandlerService handle = new ExampleEventHandlerService("tal and alon", new String[]{"1"});
        ExampleEvent ex = new ExampleEvent("10");
        handle.subscribeEvent(ExampleEvent.class, new Callback<ExampleEvent>() {
            @Override
            public void call(ExampleEvent c) throws InterruptedException {
                System.out.println("hello");
            }
        });
        ExampleMessageSenderService sender = new ExampleMessageSenderService("sender", new String[]{"event"});
        Future<String> fut = sender.sendEvent(ex);
        handle.complete(ex, "sdf");
        assertTrue(fut.isDone());
    }

    @Test
    void sendBroadcast() {
        ExampleBroadcastListenerService listener = new ExampleBroadcastListenerService("tal and alon", new String[]{"1"});
        ExampleMessageSenderService sender = new ExampleMessageSenderService("sender", new String[]{"broadcast"});
        listener.subscribeBroadcast(ExampleBroadcast.class, new Callback<ExampleBroadcast>() {
            @Override
            public void call(ExampleBroadcast c) throws InterruptedException {
                System.out.println("hello");
            }
        });

        sender.sendBroadcast(new ExampleBroadcast("10"));
        try {
            assertTrue(test.awaitMessage(listener) != null);
        }catch (InterruptedException e) {};
    }

    @Test
    void sendEvent() throws InterruptedException {
Future<String> f = test.sendEvent(new ExampleEvent("1"));
assertFalse(f == null);
assertTrue(f.get(100, TimeUnit.MILLISECONDS)==null);
    }

    @Test
    void awaitMessage() {
        ExampleBroadcastListenerService listener = new ExampleBroadcastListenerService("tal and alon", new String[]{"1"});
        ExampleMessageSenderService sender = new ExampleMessageSenderService("sender", new String[]{"broadcast"});
        listener.subscribeBroadcast(ExampleBroadcast.class, new Callback<ExampleBroadcast>() {
            @Override
            public void call(ExampleBroadcast c) throws InterruptedException {
                System.out.println("hello");
            }
        });
        sender.sendBroadcast(new ExampleBroadcast("10"));
        try {
            assertTrue(test.awaitMessage(listener) != null);
        }catch (InterruptedException e) {};
    }
}
