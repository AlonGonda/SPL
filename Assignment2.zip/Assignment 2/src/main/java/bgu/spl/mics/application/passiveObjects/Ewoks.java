package bgu.spl.mics.application.passiveObjects;

import java.util.ArrayList;

/**
 * Passive object representing the resource manager.
 * <p>
 * This class must be implemented as a thread-safe singleton. You must not alter
 * any of the given public methods of this class.
 * <p>
 */
public class Ewoks {
	private static Ewoks instance = null;
	private ArrayList<Ewok> ewoks;

	private Ewoks(int size) {
		ewoks = new ArrayList<Ewok>();
		for (int i = 1; i <= size; i++)
			ewoks.add(new Ewok(i));
	}

	public void acquireEwok(int serial) throws InterruptedException {
		Ewok attackedEwok = ewoks.get(serial - 1);
		synchronized (attackedEwok) {
			while (!attackedEwok.isAvailable()) {
				attackedEwok.wait();
			}
			attackedEwok.acquire();
		}
	}

	public void releaseEwok(int serial) {
		Ewok attackedEwok = ewoks.get(serial - 1);
		attackedEwok.release();
		synchronized (attackedEwok) {
			attackedEwok.notifyAll();
		}
	}

	// Get The Ewoks List
	public static Ewoks getInstance(int num, boolean init) {
		if (instance == null || init) {
			instance = new Ewoks(num);
		}
		return instance;
	}

}
