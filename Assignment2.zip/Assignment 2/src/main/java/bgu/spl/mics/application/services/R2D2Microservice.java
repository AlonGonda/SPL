package bgu.spl.mics.application.services;

import bgu.spl.mics.Callback;
import bgu.spl.mics.MicroService;
import bgu.spl.mics.application.messages.DeactivationEvent;
import bgu.spl.mics.application.messages.TerminateBroadcast;
import bgu.spl.mics.application.passiveObjects.Diary;

/**
 * R2D2Microservices is in charge of the handling {@link DeactivationEvent}.
 * This class may not hold references for objects which it is not responsible
 * for: {@link DeactivationEvent}.
 *
 * You can add private fields and public methods to this class. You MAY change
 * constructor signatures and even add new public constructors.
 */
public class R2D2Microservice extends MicroService {
	private int delayTime;

	public R2D2Microservice(int delayTime) {
		super("R2D2");
		this.delayTime = delayTime;
	}

	@Override
	protected void initialize() {
		long start = System.currentTimeMillis();
		subscribeEvent(DeactivationEvent.class, new Callback<DeactivationEvent>() {
			@Override
			public void call(DeactivationEvent c) {
				try {
					Thread.sleep(delayTime);
				} catch (InterruptedException e) {}
				Diary.getInstance().setR2D2Deactivate(System.currentTimeMillis() - start);
				complete(c, true);
			}
		});
		subscribeBroadcast(TerminateBroadcast.class, new Callback<TerminateBroadcast>() {
			@Override
			public void call(TerminateBroadcast c) throws InterruptedException {
				terminate();
				Diary.getInstance().setR2D2Terminate(System.currentTimeMillis() - start);
			}
		});
	}
}
