package bgu.spl.mics.application;

import java.io.FileWriter;
import java.io.IOException;

import com.google.gson.Gson;

import bgu.spl.mics.MicroService;
import bgu.spl.mics.application.passiveObjects.Diary;
import bgu.spl.mics.application.passiveObjects.Ewoks;
import bgu.spl.mics.application.passiveObjects.Input;
import bgu.spl.mics.application.passiveObjects.JsonInputReader;
import bgu.spl.mics.application.services.C3POMicroservice;
import bgu.spl.mics.application.services.HanSoloMicroservice;
import bgu.spl.mics.application.services.LandoMicroservice;
import bgu.spl.mics.application.services.LeiaMicroservice;
import bgu.spl.mics.application.services.R2D2Microservice;

/**
 * This is the Main class of the application. You should parse the input file,
 * create the different components of the application, and run the system. In
 * the end, you should output a JSON.
 */
public class Main {
	public static void main(String[] args) {
		Input input;
		try {
			input = JsonInputReader.getInputFromJson(args[0]);
			R2D2Microservice R2D2 = new R2D2Microservice(input.getR2D2());
			Ewoks.getInstance(input.getEwoks(), true);
			C3POMicroservice C3PO = new C3POMicroservice();
			HanSoloMicroservice HanSolo = new HanSoloMicroservice();
			LandoMicroservice Lando = new LandoMicroservice(input.getLando());
			LeiaMicroservice Leia = new LeiaMicroservice(input.getAttacks());
			MicroService[] svc = { R2D2, C3PO, HanSolo, Lando, Leia };
			Thread[] t = new Thread[svc.length];
			for (int i = 0; i < svc.length; i++) {
				t[i] = new Thread(svc[i], svc[i].getClass().getName());
				t[i].start();
			}
			for (int i = 0; i < t.length; i++) {
				try {
					t[i].join();
				} catch (InterruptedException e) {}
			}
			Gson gson = new Gson();
			FileWriter out = new FileWriter(args[1]);
			if (Diary.getInstance().getTotalAttacks() == input.getAttacks().length)
				System.out.println("\n\tall attacks commenced");
			gson.toJson(Diary.getInstance(), out);
			out.flush();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
