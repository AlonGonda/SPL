package bgu.spl.mics.application.services;

import bgu.spl.mics.Future;
import bgu.spl.mics.MicroService;
import bgu.spl.mics.application.messages.AttackEvent;
import bgu.spl.mics.application.messages.BombDestroyerEvent;
import bgu.spl.mics.application.messages.DeactivationEvent;
import bgu.spl.mics.application.messages.TerminateBroadcast;
import bgu.spl.mics.application.passiveObjects.Attack;
import bgu.spl.mics.application.passiveObjects.Diary;

/**
 * LeiaMicroservices Initialized with Attack objects, and sends them as
 * {@link AttackEvent}. This class may not hold references for objects which it
 * is not responsible for: {@link AttackEvent}.
 *
 * You can add private fields and public methods to this class. You MAY change
 * constructor signatures and even add new public constructors.
 */
public class LeiaMicroservice extends MicroService {
	private Attack[] attacks;
	private Future<Boolean>[] futures;

	@SuppressWarnings("unchecked")
	public LeiaMicroservice(Attack[] attacks) {
		super("Leia");
		this.attacks = attacks;
		futures = new Future[this.attacks.length];
	}

	@Override
	protected void initialize() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {}
		long start = System.currentTimeMillis();
		for (int i = 0; i < attacks.length; i++) {
			futures[i] = sendEvent(new AttackEvent(attacks[i]));
		}
		for (int i = 0; i < attacks.length; i++) {
			futures[i].get();
		}
		sendEvent(new DeactivationEvent()).get();
		sendEvent(new BombDestroyerEvent()).get();
		terminate();
		sendBroadcast(new TerminateBroadcast());
		long end = System.currentTimeMillis();
		Diary.getInstance().setLeiaTerminate(end - start);
	}

}
