package bgu.spl.mics.application.services;

import java.util.List;

import bgu.spl.mics.Callback;
import bgu.spl.mics.MicroService;
import bgu.spl.mics.application.messages.AttackEvent;
import bgu.spl.mics.application.messages.TerminateBroadcast;
import bgu.spl.mics.application.passiveObjects.Diary;
import bgu.spl.mics.application.passiveObjects.Ewoks;

/**
 * C3POMicroservices is in charge of the handling {@link AttackEvents}. This
 * class may not hold references for objects which it is not responsible for:
 * {@link AttackEvents}.
 *
 * You can add private fields and public methods to this class. You MAY change
 * constructor signatures and even add new public constructors.
 */
public class C3POMicroservice extends MicroService {

	public C3POMicroservice() {
		super("C3PO");
	}

	@Override
	protected void initialize() {
		long start = System.currentTimeMillis();
		subscribeEvent(AttackEvent.class, new Callback<AttackEvent>() {
			@Override
			public void call(AttackEvent c) throws InterruptedException {
				List<Integer> ewoks = c.getAttack().getEwoks();
				Ewoks instance = Ewoks.getInstance(0, false);
				for (Integer ewokNum : ewoks) {
					instance.acquireEwok(ewokNum);
					Thread.sleep(c.getAttack().getDuration());
					instance.releaseEwok(ewokNum);
				}
				Diary d = Diary.getInstance();
				d.setC3POFinish(System.currentTimeMillis() - start);
				d.setTotalAttacks(d.getTotalAttacks() + 1);
				complete(c, true);
			}
		});
		subscribeBroadcast(TerminateBroadcast.class, new Callback<TerminateBroadcast>() {
			@Override
			public void call(TerminateBroadcast c) throws InterruptedException {
				terminate();
				Diary.getInstance().setC3POTerminate(System.currentTimeMillis() - start);
			}
		});
		//System.out.println(getName() + " initiazlied");
	}
}
