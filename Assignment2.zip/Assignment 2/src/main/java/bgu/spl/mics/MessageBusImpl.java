package bgu.spl.mics;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * The {@link MessageBusImpl class is the implementation of the MessageBus
 * interface. Write your implementation here! Only private fields and methods
 * can be added to this class.
 * 
 * @param <T>
 */
public class MessageBusImpl implements MessageBus {

	private static final MessageBus instance = new MessageBusImpl();

	@SuppressWarnings("rawtypes")
	private ConcurrentHashMap<Event, Future> futures;
	private ConcurrentHashMap<Class<? extends Event<?>>, ConcurrentLinkedQueue<MicroService>> eventSubscribers;
	private ConcurrentHashMap<Class<? extends Broadcast>, ConcurrentLinkedQueue<MicroService>> broadcastSubscribers;
	private ConcurrentHashMap<MicroService, ConcurrentLinkedQueue<Message>> messagesQueue;

	public static final MessageBus getInstance() {
		return instance;
	}

	private MessageBusImpl() {
		futures = new ConcurrentHashMap<>();
		eventSubscribers = new ConcurrentHashMap<>();
		broadcastSubscribers = new ConcurrentHashMap<>();
		messagesQueue = new ConcurrentHashMap<>();
	}

	@Override
	public <T> void subscribeEvent(Class<? extends Event<T>> type, MicroService m) {
		ConcurrentLinkedQueue<MicroService> subs;
		if (!eventSubscribers.containsKey(type)) {
			subs = new ConcurrentLinkedQueue<>();
			eventSubscribers.put(type, subs);
		}
		else
			subs = eventSubscribers.get(type);
		subs.add(m);
	}

	@Override
	public synchronized void subscribeBroadcast(Class<? extends Broadcast> type, MicroService m) {
		ConcurrentLinkedQueue<MicroService> subs;
		if (!broadcastSubscribers.containsKey(type)) {
			subs = new ConcurrentLinkedQueue<>();
			broadcastSubscribers.put(type, subs);
		}
		else
			subs = broadcastSubscribers.get(type);
		subs.add(m);
		notifyAll();
	}

	@Override
	@SuppressWarnings("unchecked")
	public <T> void complete(Event<T> e, T result) {
		futures.get(e).resolve(result);
	}

	@Override
	public void sendBroadcast(Broadcast b) {
		if (!broadcastSubscribers.containsKey(b.getClass()))
			return;
		ConcurrentLinkedQueue<MicroService> subs = broadcastSubscribers.get(b.getClass());
		if (subs.isEmpty())
			return;
		for (MicroService m : subs) {
			sendMessage(m, b);
		}
	}

	@Override
	public <T> Future<T> sendEvent(Event<T> e) {
		Future<T> f = new Future<>();
		futures.put(e, f);
		if (!eventSubscribers.containsKey(e.getClass())) {
			System.out.println("unknown event: " + e.getClass().getSimpleName());
			complete(e, null);
			return null;
		}
		ConcurrentLinkedQueue<MicroService> subs = eventSubscribers.get(e.getClass());
		MicroService m;
		synchronized (subs) {
			if (subs.isEmpty()) {
				System.out.println("no subscribers to " + e.getClass().getSimpleName());
				complete(e, null);
				return null;
			}
			// round robin logic
			subs.add(m = subs.poll());
		}
		sendMessage(m, e);
		return f;
	}

	@Override
	public void register(MicroService m) {
		messagesQueue.put(m, new ConcurrentLinkedQueue<>());
	}

	@Override
	public void unregister(MicroService m) {
		messagesQueue.remove(m);
		for (ConcurrentLinkedQueue<MicroService> subs : eventSubscribers.values()) {
			subs.remove(m);
		}
		for (ConcurrentLinkedQueue<MicroService> subs : broadcastSubscribers.values()) {
			subs.remove(m);
		}
	}

	/**
	 * Add {@code msg} to the {@code m} messages queue and notify {@code m} that
	 * a message has arrived
	 * 
	 * @param m
	 *            the {@link MicroService} that the message is designated to
	 * @param msg
	 *            the message that has arrived
	 */
	private void sendMessage(MicroService m, Message msg) {
		messagesQueue.get(m).add(msg);
		synchronized (m) {
			m.notifyAll();
		}
	}

	@Override
	public Message awaitMessage(MicroService m) throws InterruptedException {
		while (messagesQueue.containsKey(m)) {
			ConcurrentLinkedQueue<Message> msgQueue = messagesQueue.get(m);
			if (!msgQueue.isEmpty())
				return msgQueue.remove();
			synchronized (m) {
				m.wait();
			}
		}
		return null;
	}
}
