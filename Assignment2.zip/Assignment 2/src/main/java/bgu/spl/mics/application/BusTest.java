package bgu.spl.mics.application;

import bgu.spl.mics.MessageBus;
import bgu.spl.mics.MessageBusImpl;
import bgu.spl.mics.example.services.ExampleEventHandlerService;
import bgu.spl.mics.example.services.ExampleMessageSenderService;

public class BusTest {

	public static void main(String[] args) throws InterruptedException {
		MessageBus test = MessageBusImpl.getInstance();
		ExampleEventHandlerService handle = new ExampleEventHandlerService("tal and alon", new String[] { "1" });
		ExampleMessageSenderService sender = new ExampleMessageSenderService("sender", new String[] { "event" });
		Thread h = new Thread(handle);
		Thread s = new Thread(sender);
		h.start();
		synchronized (s) {
			s.wait(100);
			s.start();
		}
		s.join();
		h.join();
		System.out.println(test.awaitMessage(handle) == null);
	}

}
