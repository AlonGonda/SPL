package bgu.spl.mics.application.services;

import bgu.spl.mics.Callback;
import bgu.spl.mics.MicroService;
import bgu.spl.mics.application.messages.BombDestroyerEvent;
import bgu.spl.mics.application.messages.TerminateBroadcast;
import bgu.spl.mics.application.passiveObjects.Diary;

/**
 * LandoMicroservice You can add private fields and public methods to this
 * class. You MAY change constructor signatures and even add new public
 * constructors.
 */
public class LandoMicroservice extends MicroService {

	private int delay;

	public LandoMicroservice(int delay) {
		super("Lando");
		this.delay = delay;
	}

	@Override
	protected void initialize() {
		long start = System.currentTimeMillis();
		subscribeEvent(BombDestroyerEvent.class, new Callback<BombDestroyerEvent>() {
			@Override
			public void call(BombDestroyerEvent c) {
				try {
					Thread.sleep(delay);
				} catch (InterruptedException e) {}
				Diary.getInstance().setLandoFinish(System.currentTimeMillis()-start);
				complete(c, true);
			}
		});
		subscribeBroadcast(TerminateBroadcast.class, new Callback<TerminateBroadcast>() {
			@Override
			public void call(TerminateBroadcast c) throws InterruptedException {
				terminate();
				Diary.getInstance().setLandoTerminate(System.currentTimeMillis() - start);
			}
		});
		//System.out.println(getName() + " initiazlied");
	}
}
