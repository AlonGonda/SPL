#include "Tree.h"

RootTree::RootTree(int rootLabel): Tree(rootLabel) {}

RootTree::RootTree(const RootTree& copy): Tree(copy) {}

RootTree::RootTree(RootTree&& other): Tree(other) {}

const RootTree& RootTree::operator=(const RootTree& other) {
    Tree::operator=(other);
    return *this;
}

const RootTree& RootTree::operator=(RootTree&& other) {
     if(this == &other)
        return *this;
    clear();
    node = other.node;
    std::swap(children, other.children);
    return *this;
}

Tree *RootTree::clone() const {
    return new RootTree(*this);
}

int RootTree::traceTree() {
    return node;
}

RootTree::~RootTree() noexcept {}
