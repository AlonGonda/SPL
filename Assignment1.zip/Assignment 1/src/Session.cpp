#include "Session.h"
#include "Agent.h"
#include <iostream>

using json = nlohmann::json;
using namespace std;

Session::Session(const string& path) : g(), treeType {MaxRank}, agents(), infected_queue {}, current_cycle { -1} {
    ifstream i(path);
    json j;
    i >> j;
    parse_graph(j["graph"]);
    parse_agents(j["agents"].dump());
    parse_tree_type(j["tree"].dump());
}

Session::Session(const Session& copy) : g {copy.g}, treeType {copy.treeType}, agents {}, infected_queue {copy.infected_queue}, current_cycle {copy.current_cycle}  {
    for(auto i = copy.agents.begin(); i != copy.agents.end(); ++i) {
        agents.push_back((*i)->clone());
    }
}

Session::Session(Session&& other) : g {other.g}, treeType {other.treeType}, agents {other.agents}, infected_queue {other.infected_queue}, current_cycle {other.current_cycle}  {
    other.agents.clear();
}

const Session &Session::operator=(const Session &other) {
    if(this == &other)
        return *this;
    g = other.g;
    treeType = other.treeType;
    current_cycle = other.current_cycle;
    // releases current memory and clears the agents vector
    clean_up();
    for(auto i = other.agents.begin(); i != other.agents.end(); ++i) {
        agents.push_back((*i)->clone());
    }
    infected_queue = other.infected_queue;
    return *this;
}

const Session &Session::operator=(Session &&other) {
    if (this == &other)
        return *this;
    clean_up(); // in case of std::move
    swap(agents, other.agents);
    g = other.g;
    treeType = other.treeType;
    infected_queue = other.infected_queue;
    current_cycle = other.current_cycle;
    return *this;
}

void Session::parse_graph(const vector<vector<int> > &raw_graph) {
    g = raw_graph;
}

void Session::parse_tree_type(const string &raw_tree_type) {
    switch(raw_tree_type[1]) {
    case 'C':
        treeType = Cycle;
        break;
    case 'R':
        treeType = Root;
        break;
    case 'M':
    default: // choosing max rank as default
        treeType = MaxRank;
        break;
    }
}

void Session::parse_agents(const string &raw_agents) {
    for(auto i = raw_agents.begin(); i != raw_agents.end(); ++i) {
        if(*i == 'V') {
            int node_index = *(i + 3) - '0';
            add_agent(new Virus(node_index));
            g.infectNode(node_index);
        }
        else if(*i == 'C')
            add_agent(new ContactTracer());
    }
}

void Session::simulate() {
    current_cycle = -1;
    while(!g.secluded()) {
        ++current_cycle;
        unsigned int current_agents_size = agents.size();
        for(unsigned int i = 0; i < current_agents_size; ++i) {
            agents[i]->act(*this);
        }
    }
    to_json();
}

void Session::to_json() {
    json j;
    ofstream o("output.json");
    j["graph"] = g.get_edges();
    j["infected"] = g.get_infected_nodes();
    o << j;
}

const Graph &Session::get_graph() const {
    return g;
}

Graph &Session::getGraph() {
    return g;
}


void Session::enqueueInfected(int i) {
    infected_queue.push_back(i);
}

TreeType Session::getTreeType() const {
    return treeType;
}

void Session::addAgent(const Agent & agent) {
    add_agent(agent.clone());
}

void Session::add_agent(Agent * agent) {
    agents.push_back(agent);
}

void Session::setGraph(const Graph & graph) {
    g = graph;
}

bool Session::has_queued_infected() {
    return !infected_queue.empty();
}


int Session::dequeueInfected() {
    return *infected_queue.erase(infected_queue.begin());
}

void Session::remove_neighbors(int node) {
    g.remove_neighbors(node);
}

int Session::get_current_cycle() const {
    return current_cycle;
}

void Session::clean_up() noexcept {
    for(auto i = agents.begin(); i != agents.end(); ++i)
        delete *i;
    agents.clear();
}

Session::~Session() {
    clean_up();
}

