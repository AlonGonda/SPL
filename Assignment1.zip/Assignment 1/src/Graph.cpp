#include "Graph.h"

using std::vector;

Graph::Graph() : edges {}, nodes_type {} {}

Graph::Graph(vector<vector<int> > matrix): edges {matrix}, nodes_type(matrix.size()) {
    for(unsigned int i = 0; i < edges.size(); i++) {
        nodes_type[i] = Node_type::healthy;
    }
}

const vector<vector<int> >& Graph::get_edges() const {
    return edges;
}

void Graph::addEdge(int first, int second) {
    this->edges.at(first).at(second) = 1;
    this->edges.at(second).at(first) = 1;
}

void Graph::deleteEdge(int first, int second) {
    this->edges.at(first).at(second) = 0;
    this->edges.at(second).at(first) = 0;
}

void Graph::infectNode(int nodeInd) {
    nodes_type[nodeInd] = Node_type::infected;
}

bool Graph::isInfected(int nodeInd) {
    return (nodes_type[nodeInd] == Node_type::infected);
}
void Graph::makeSick(int node) {
    nodes_type[node] = Node_type::sick;
}

bool Graph::isSick(int nodeInd) {
    return (nodes_type[nodeInd] == Node_type::sick);
}

int Graph::get_healthy_neighbor(int node) {
    auto me = edges.at(node);
    for(unsigned int i = 0; i < me.size(); ++i) {
        if(edges[node][i] == 1 && nodes_type[i] == Node_type::healthy) {
            return i;
        }
    }
    return -1;
}

void Graph::remove_neighbors(int node_index) {
    for(unsigned int i = 0; i < edges.size(); ++i) {
        edges[i][node_index] = edges[node_index][i] = 0;
    }
}

vector<int> Graph::get_infected_nodes() {
    vector<int> infected;
    for(unsigned int i = 0; i < nodes_type.size(); ++i) {
        if(nodes_type[i] != Node_type::healthy) {
            infected.push_back(i);
        }
    }
    return infected;
}

bool Graph::secluded() const {
    for(unsigned int i = 0; i < edges.size(); ++i)
        if(nodes_type[i] == Node_type::healthy)
            for(unsigned int j = 0; j < edges.size(); ++j)
                if(edges[i][j] == 1 && nodes_type[j] != Node_type::healthy)
                    return false;
    return true;
}
