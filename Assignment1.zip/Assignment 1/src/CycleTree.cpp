#include "Tree.h"

CycleTree::CycleTree(int rootLabel, int currCycle): Tree(rootLabel), currCycle(currCycle) {}

CycleTree::CycleTree(const CycleTree& copy): Tree(copy.node), currCycle {copy.currCycle} {}

CycleTree::CycleTree(CycleTree&& other): Tree(other.node), currCycle{other.currCycle} {}

const CycleTree& CycleTree::operator=(const CycleTree& other) {
    Tree::operator=(other);
    currCycle = other.currCycle;
    return *this;
}

const CycleTree& CycleTree::operator=(CycleTree&& other) {
    if(this == &other)
        return *this;
    clear();
    node = other.node;
    std::swap(children, other.children);
    currCycle = other.currCycle;
    return *this;
}

Tree *CycleTree::clone() const {
    return new CycleTree(*this);
}

int CycleTree::traceTree() {
    Tree *current = this;
    int num = currCycle;
    while(num-- > 0 && current->getChildren().size() != 0) {
        current = current->getChildren().at(0);
    }
    return current->getNode();
}

CycleTree::~CycleTree() noexcept {}
