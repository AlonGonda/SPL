#include "Tree.h"

MaxRankTree::MaxRankTree(int rootLabel): Tree(rootLabel) {}

MaxRankTree::MaxRankTree(const MaxRankTree& copy): Tree(copy) {}

MaxRankTree::MaxRankTree(MaxRankTree&& other): Tree(std::move(other)) {}

const MaxRankTree& MaxRankTree::operator=(const MaxRankTree& other) {
    Tree::operator=(other);
    return *this;
}

const MaxRankTree& MaxRankTree::operator=(MaxRankTree&& other) {
    if(this == &other)
        return *this;
    clear();
    node = other.node;
    std::swap(children, other.children);
    return *this;
}

Tree *MaxRankTree::clone() const {
    return new MaxRankTree(*this);
}

int MaxRankTree::traceTree() {
    Tree *current = this;
    Tree *max_rank = this;
    std::list<Tree *> queue;
    queue.push_back(current);
    while(!queue.empty()) {
        current = queue.front();
        queue.pop_front();
        auto childern = current->getChildren();
        for(auto i = childern.begin(); i != childern.end(); i++) {
            queue.push_back(*i);
            if((*i)->getChildren().size() > max_rank->getChildren().size())
                max_rank = *i;
        }
    }
    return max_rank->getNode();
}

MaxRankTree::~MaxRankTree() noexcept {}
