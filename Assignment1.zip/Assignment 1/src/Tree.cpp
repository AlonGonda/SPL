#include "Tree.h"
#include<iostream>

//constructor Tree
Tree::Tree(int rootLabel): node(rootLabel), children() {}

Tree::Tree(const Tree& copy) : node(copy.node), children() {
    for(auto i = copy.children.begin(); i != copy.children.end(); i++) {
        children.push_back((*i)->clone());
    }
}

Tree::Tree(Tree&& other) : node(other.node), children(other.children) {
    other.children.clear();
}

const Tree& Tree::operator=(const Tree& other) {
    if(this == &other)
        return *this;
    node = other.node;
    clear();
    for(auto i = other.children.begin(); i != other.children.end(); i++)
        children.push_back((*i)->clone());
    return *this;
}

const Tree& Tree::operator=(Tree&& other) {
    if(this == &other)
        return *this;
    clear();
    std::swap(children, other.children);
    node = other.node;
    return *this;
}

void Tree::clear() {
    for(auto i = children.begin(); i != children.end(); i++) {
        delete *i;
    }
    children.clear();
}

int Tree::getNode() {
    return node;
}

void Tree::addChild(const Tree& child) {
    children.push_back(child.clone());
}

std::vector<Tree *> Tree::getChildren() {
    return children;
}

Tree *Tree::createTree(const Session& session, int rootLabel) {
    TreeType type = session.getTreeType();
    if(type == MaxRank)
        return new MaxRankTree(rootLabel);
    if(type == Cycle)
        return new CycleTree(rootLabel, session.get_current_cycle());
    return new RootTree(rootLabel);
}

void Tree::add_child(Tree *child) {
    children.push_back(child);
}

Tree *Tree::create_bfs_tree(const Session &session, int root) {
    Tree *bfs = Tree::createTree(session, root);
    auto edges = session.get_graph().get_edges();
    std::vector<int> visited(edges.size());
    for(unsigned int i = 0; i < visited.size(); i++)
        visited[i] = -1;
    visited[root] = 0;
    std::list<Tree *> queue;
    queue.push_back(bfs);
    while(!queue.empty()) {
        Tree *current = queue.front();
        queue.pop_front();
        for(unsigned int i = 0; i < edges.size(); ++i) {
            if(visited[i] == -1 && edges.at(current->node).at(i) == 1) {
                visited[i] = visited[current->node] + 1;
                Tree *child = Tree::createTree(session, i);
                current->add_child(child);
                queue.push_back(child);
            }
        }
    }
    return bfs;
}

Tree::~Tree() {
    clear();
}
