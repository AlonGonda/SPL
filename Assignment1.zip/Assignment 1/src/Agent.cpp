#include "Agent.h"
#include "Tree.h"

Agent::Agent() {}

Agent::~Agent() {}

ContactTracer::ContactTracer() :  Agent() {}

Agent *ContactTracer::clone() const {
    return new ContactTracer();
}

void ContactTracer::act(Session& session) {
    if(!session.has_queued_infected())
        return;
    int infected = session.dequeueInfected();
    Tree *t = Tree::create_bfs_tree(session, infected);
    int to_remove = t->traceTree();
    session.getGraph().remove_neighbors(to_remove);
    delete t;
}

ContactTracer::~ContactTracer() {}

Virus::Virus(int nodeInt) : Agent(), nodeInd {nodeInt} {}

Agent *Virus::clone() const {
    return new Virus(nodeInd);
}

void Virus::act(Session& session) {
    // on the first act of the virus
    if(!session.getGraph().isSick(nodeInd)) {
        session.getGraph().makeSick(nodeInd);
        session.enqueueInfected(nodeInd);
    }
    int to_infect = session.getGraph().get_healthy_neighbor(nodeInd);
    if(to_infect == -1)
        return;
    session.getGraph().infectNode(to_infect);
    session.add_agent(new Virus(to_infect));
}

Virus::~Virus() {}
