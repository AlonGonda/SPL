#ifndef TREE_H_
#define TREE_H_

#include <vector>
#include "Session.h"
#include "Graph.h"

class Tree {
public:
    Tree(int rootLabel);
    void addChild(const Tree& child);
    void add_child(Tree *);
    std::vector<Tree*> getChildren();
    int getNode();
    static Tree *createTree(const Session& session, int rootLabel);
    static Tree *create_bfs_tree(const Session &session, int root);
    Tree(const Tree &copy);
    Tree(Tree&& other);
    const Tree& operator=(const Tree& other);
    const Tree& operator=(Tree&& other);
    virtual int traceTree() = 0;
    virtual Tree *clone() const = 0;
    virtual ~Tree();
protected:
    int node;
    std::vector<Tree *> children;

    void clear();
};

class CycleTree: public Tree {
public:
    CycleTree(int rootLabel, int currCycle);
    CycleTree(const CycleTree &copy);
    CycleTree(CycleTree&& other);
    const CycleTree& operator=(const CycleTree& other);
    const CycleTree& operator=(CycleTree&& other);
    virtual int traceTree();
    virtual ~CycleTree();
    virtual Tree * clone() const;
private:
    int currCycle;
};

class MaxRankTree: public Tree {
public:
    MaxRankTree(int rootLabel);
    MaxRankTree(const MaxRankTree &copy);
    MaxRankTree(MaxRankTree&& other);
    const MaxRankTree& operator=(const MaxRankTree& other);
    const MaxRankTree& operator=(MaxRankTree&& other);
    virtual int traceTree();
    virtual ~MaxRankTree();
    virtual Tree *clone() const;
};

class RootTree: public Tree {
public:
    RootTree(int rootLabel);
    RootTree(const RootTree &copy);
    RootTree(RootTree&& other);
    const RootTree& operator=(const RootTree& other);
    const RootTree& operator=(RootTree&& other);
    virtual int traceTree();
    virtual ~RootTree();
    virtual Tree *clone() const;
};

#endif
