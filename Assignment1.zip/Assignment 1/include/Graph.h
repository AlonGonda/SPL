#ifndef GRAPH_H_INCLUDED
#define GRAPH_H_INCLUDED

#include <vector>
#include <list>

//class Session;

enum class Node_type {
    healthy, infected, sick
};

class Graph {
public:
    Graph();
    Graph(std::vector<std::vector<int> > matrix);
    void infectNode(int nodeInd);
    bool isInfected(int nodeInd);
    bool isSick(int nodeInd);
    std::vector<int> get_infected_nodes();
    void deleteEdge(int first, int second);
    void addEdge(int first, int second);
    const std::vector<std::vector<int> >& get_edges() const;
    bool secluded() const;
    void makeSick (int node);
    int get_healthy_neighbor(int myindex);
    void remove_neighbors(int node_index);
private:
    std::vector<std::vector<int> > edges;
    std::vector<Node_type> nodes_type;
};

#endif // GRAPH_H_INCLUDED
