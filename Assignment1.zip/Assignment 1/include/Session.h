#ifndef SESSION_H_INCLUDED
#define SESSION_H_INCLUDED

#include <vector>
#include <string>
#include <fstream>
#include "Graph.h"
#include "json.hpp"

class Agent;

enum TreeType {
    Cycle,
    MaxRank,
    Root
};

class Session {
public:
    Session(const std::string& path);
    Session(const Session& copy);
    Session(Session&& other);

    const Session &operator=(const Session &other);
    const Session &operator=(Session &&other);

    void simulate();
    void addAgent(const Agent& agent);
    void add_agent(Agent *);
    void setGraph(const Graph& graph);

    void enqueueInfected(int);
    int dequeueInfected();
    bool has_queued_infected();
    TreeType getTreeType() const;
    const Graph &get_graph() const;
    Graph &getGraph();
    void remove_neighbors(int);
    int get_current_cycle() const;

    ~Session();

private:
    Graph g;
    TreeType treeType;
    std::vector<Agent *> agents;
    std::vector<int> infected_queue;
    int current_cycle;

    void parse_graph(const std::vector<std::vector<int> >& raw_graph);
    void parse_tree_type(const std::string& raw_tree_type);
    void parse_agents(const std::string& raw_agents);
    void to_json();
    void clean_up() noexcept;
};


#endif // SESSION_H_INCLUDED
