import sqlite3
from Repository import repo
import DTO


def parse(path):
    dbcp = sqlite3.connect("database.db")
    inputFile = open(path)
    lines = []
    for line in inputFile:
        line = line.replace("\n", "")
        line = line.split(",")
        lines.append(line)
    currentRow = 1
    table = 1
    for cell in lines[0]:
        cell = int(cell)
        i = 0
        while i < cell:
            addDataToDB(table, lines[currentRow])
            i = i + 1
            currentRow = currentRow + 1
        table = table + 1
    dbcp.commit()


def addDataToDB(num, line):
    if num == 1:
        repo.vaccines.insert(DTO.Vaccines(int(line[0]), str(line[1]), int(line[2]), int(line[3])))
    elif num == 2:
        repo.suppliers.insert(DTO.Suppliers(int(line[0]), str(line[1]), int(line[2])))
    elif num == 3:
        repo.clinics.insert(DTO.Clinics(int(line[0]), str(line[1]), int(line[2]), int(line[3])))
    elif num == 4:
        repo.logistics.insert(DTO.Logistics(int(line[0]), str(line[1]), int(line[2]), int(line[3])))
