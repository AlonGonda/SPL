import DTO


def parse_string(text):
    text = text.replace("'", "")
    text = text.replace(" ", "")
    text = text.replace("(", "")
    text = text.replace(")", "")
    return text.split(",")


class _Vaccines:
    def __init__(self, conn):
        self._conn = conn
        self.last_id = 0

    def insert(self, vaccine):
        self._conn.execute("INSERT into vaccines Values(?,?,?,?)",
                           (vaccine.id, vaccine.date, vaccine.supplier, vaccine.quantity))
        self.last_id = self.last_id + 1

    def find(self):
        c = self._conn.cursor()
        c.execute("SELECT * FROM vaccines ORDER BY date ASC")
        line = parse_string(str(c.fetchone()))
        return DTO.Vaccines(line[0], line[1], line[2], line[3])

    def reduce_quantity(self, vaccine):
        self._conn.execute("""
               UPDATE vaccines SET quantity=(?) WHERE id=(?)
           """, [vaccine.quantity, vaccine.id])

    def delete_empty(self, vaccine):
        self._conn.execute("DELETE FROM vaccines WHERE id=(?)", [vaccine.id])

    def total_inventory(self):
        total = 0
        c = self._conn.cursor()
        c.execute("SELECT * FROM vaccines")
        rows = c.fetchall()
        for row in rows:
            row = parse_string(str(row))
            total = total + int(row[3])
        return str(total)


class _Suppliers:
    def __init__(self, conn):
        self._conn = conn

    def insert(self, supplier):
        self._conn.execute("INSERT into suppliers Values(?,?,?)",
                           (supplier.id, supplier.name, supplier.logistic))

    def find(self, supplier_id):
        c = self._conn.cursor()
        c.execute("SELECT * FROM suppliers WHERE id = ?", [supplier_id])
        line = parse_string(str(c.fetchone()))
        return DTO.Suppliers(line[0], line[1], line[2])

    def find_by_name(self, supplier_name):
        c = self._conn.cursor()
        c.execute("SELECT * FROM suppliers WHERE name = ?", [supplier_name])
        line = parse_string(str(c.fetchone()))
        return DTO.Suppliers(line[0], line[1], line[2])


class _Clinics:
    def __init__(self, conn):
        self._conn = conn

    def insert(self, clincic):
        self._conn.execute("INSERT into clinics Values(?,?,?,?)",
                           (clincic.id, clincic.location, clincic.demand, clincic.logistic))

    def find(self, clinic_location):
        c = self._conn.cursor()
        c.execute("SELECT * FROM Clinics WHERE location = ?", [clinic_location])
        line = parse_string(str(c.fetchone()))
        return DTO.Clinics(line[0], line[1], line[2], line[3])

    def reduce_demand(self, clinic):
        self._conn.execute("""
               UPDATE clinics SET demand=(?) WHERE location=(?)
           """, [clinic.demand, clinic.location])

    def total_demand(self):
        total = 0
        c = self._conn.cursor()
        c.execute("SELECT * FROM clinics")
        rows = c.fetchall()
        for row in rows:
            row = parse_string(str(row))
            total = total + int(row[2])
        return str(total)


class _Logistics:
    def __init__(self, conn):
        self._conn = conn

    def insert(self, logistic):
        self._conn.execute("INSERT into logistics Values(?,?,?,?)",
                           (logistic.id, logistic.name, logistic.count_sent, logistic.count_received))

    def find(self, logistic_id):
        c = self._conn.cursor()
        c.execute("SELECT * FROM logistics WHERE id = ?", [logistic_id])
        line = parse_string(str(c.fetchone()))
        return DTO.Logistics(line[0], line[1], line[2], line[3])

    def increase_sent(self, logistic):
        self._conn.execute("""
               UPDATE logistics SET count_sent=(?) WHERE id=(?)
           """, [logistic.count_sent, logistic.id])

    def increase_received(self, logistic):
        self._conn.execute("""
               UPDATE logistics SET count_received=(?) WHERE id=(?)
           """, [logistic.count_received, logistic.id])

    def total_sent_received(self):
        total = {"sent": 0, "received": 0}
        c = self._conn.cursor()
        c.execute("SELECT * FROM logistics")
        rows = c.fetchall()
        for row in rows:
            row = parse_string(str(row))
            total["sent"] = total["sent"] + int(row[2])
            total["received"] = total["received"] + int(row[3])
        return str(str(total["received"]) + "," + str(total["sent"]))
