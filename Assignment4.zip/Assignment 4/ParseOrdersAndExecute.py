import sqlite3
import sys

import DTO
from Repository import repo


def parse(path):
    output = open(sys.argv[3], "w+")
    dbcp = sqlite3.connect("database.db")
    inputFile = open(path)
    for action in inputFile:
        action = action.replace("\n", "")
        action = action.split(",")
        act(action, output)
    dbcp.commit()


def act(action, output_file):
    if len(action) == 2:
        clinic = repo.clinics.find(action[0])
        clinic_demand = int(clinic.demand)
        vaccine = repo.vaccines.find()
        shippment_demand = int(action[1])
        while (shippment_demand > 0) & (int(vaccine.quantity) < shippment_demand):
            clinic_demand = clinic_demand - int(vaccine.quantity)
            repo.vaccines.delete_empty(vaccine)
            repo.clinics.reduce_demand(DTO.Clinics(clinic.id, clinic.location, clinic_demand, clinic.logistic))
            logistic = repo.logistics.find(clinic.logistic)
            new_sent = int(logistic.count_sent) + int(vaccine.quantity)
            repo.logistics.increase_sent(DTO.Logistics(logistic.id, logistic.name, new_sent, logistic.count_received))
            shippment_demand = shippment_demand - int(vaccine.quantity)
            vaccine = repo.vaccines.find()
        repo.vaccines.reduce_quantity(
            DTO.Vaccines(vaccine.id, vaccine.date, vaccine.supplier, int(vaccine.quantity) - shippment_demand))
        repo.clinics.reduce_demand(DTO.Clinics(clinic.id, clinic.location, clinic_demand - shippment_demand, clinic.logistic))
        logistic = repo.logistics.find(clinic.logistic)
        new_sent = int(logistic.count_sent) + shippment_demand
        repo.logistics.increase_sent(DTO.Logistics(logistic.id, logistic.name, new_sent, logistic.count_received))
    else:
        supplier = repo.suppliers.find_by_name(action[0])
        quantity = action[1]
        repo.vaccines.insert(DTO.Vaccines(repo.vaccines.last_id + 1, action[2], supplier.id, quantity))
        logistic = repo.logistics.find(supplier.logistic)
        repo.logistics.increase_received(
            DTO.Logistics(logistic.id, logistic.name, logistic.count_sent, int(logistic.count_received) + int(quantity)))

    to_write = repo.vaccines.total_inventory() + "," + repo.clinics.total_demand() + "," + repo.logistics.total_sent_received()
    output_file.write(to_write + "\n")
